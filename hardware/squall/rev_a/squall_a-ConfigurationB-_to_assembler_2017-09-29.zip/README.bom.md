Squall BOM
==========

Squall comes in two possible configurations, A and B. Configuration A is
cheaper. It does not include any USB integration, just the Bluetooth.

The files `squall_bom.LEGACY` present these configurations as priced out
in 2014 with the original design. A handful of passives have been obsoleted
since then, they are not hard to replace.

The files `squall_bom.2017-09.ConfigurationB` are an updated BOM from a
manufacturing run in fall '17 for the full-featured configuration.
